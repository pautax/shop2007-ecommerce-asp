Per provare lo script caricare nel browser la pagina "CodiceFiscale.html"

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Consigliamo di inserire questo script nella vostra pagina web facendo uso di una pop-up come questa:
<SCRIPT>
<!--
function CodiceFiscale()
   {
   var codFis = window.open('CodiceFiscale.html','codFis','width=400,height=500,resizable=no,scrollbars=no,status=no,directory=no,menubar=no')
   }
//-->
</SCRIPT>

ed attivarla con un link: <A HREF="javascript:CodiceFiscale()">Genera Codice Fiscale </A>

Come spiegato nella scheda dello script (http://www.jsdir.com/staffscripts/script046.asp) 
richiede una struttura a frames per poter caricare in differita l'array dei comuni trattandosi
di un file di testo molto grosso (circa 230 KByte)

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

 - Per commenti ed informazioni scrivere a riccardo@jsdir.com

 - Questo script pu� essere usato e distribuito liberamente a patto di citarne
   la fonte che � "http://www.jsdir.com"

 - Se decidi di usare questo script all'interno della tua pagina web ti preghiamo
   di inserire all'interno del codice HTML questa riga di commento che non influenzer�
   assolutamente il funzionamento del sito:
   <!-- Questo script e' reperibile nel sito http://www.jsdir.com -->
   oppure uno dei banner o bottoni reperibili all'interno del sito sotto il link "Banner".

 - Se vuoi scambiare un banner collegati a http://www.jsdir.com e nella pagina "Banner"
   dove troverai le porzioni di codice gi� pronte e le regole per lo scambio

	Grazie.

                                          - - - - - - - - - - - - - - - - - - - - 
                                                Source site: http://www.jsdir.com
                                                   e-mal: riccardo@jsdir.com
                                          - - - - - - - - - - - - - - - - - - - -
- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
