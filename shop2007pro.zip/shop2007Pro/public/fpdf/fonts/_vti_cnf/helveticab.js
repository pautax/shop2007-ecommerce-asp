vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:00 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{023B88D3-683A-4B1E-8BF8-3D182A7E25A0}
vti_cacheddtm:TX|11 Nov 2003 12:16:00 -0000
vti_filesize:IR|4024
vti_backlinkinfo:VX|
