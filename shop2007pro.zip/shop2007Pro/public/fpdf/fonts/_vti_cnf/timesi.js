vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:06 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{A93F6827-53D6-4A15-969D-47EEDA2B9AAC}
vti_cacheddtm:TX|11 Nov 2003 12:16:06 -0000
vti_filesize:IR|4015
vti_backlinkinfo:VX|
