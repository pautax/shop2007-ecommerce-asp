vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:04 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{76DBBF1B-7C73-4EF4-8A81-8A6B490B03BC}
vti_cacheddtm:TX|11 Nov 2003 12:16:04 -0000
vti_filesize:IR|4022
vti_backlinkinfo:VX|
