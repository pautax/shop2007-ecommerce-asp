vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 16:26:48 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{E50DABF7-E265-4DB7-A1BA-4DC409E38852}
vti_cacheddtm:TX|11 Nov 2003 16:26:48 -0000
vti_filesize:IR|3736
vti_backlinkinfo:VX|
