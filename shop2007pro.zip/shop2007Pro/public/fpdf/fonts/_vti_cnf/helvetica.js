vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:15:58 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{516C9E49-B6CF-4E5D-97D7-69848726E22E}
vti_cacheddtm:TX|11 Nov 2003 12:15:58 -0000
vti_filesize:IR|4024
vti_backlinkinfo:VX|
