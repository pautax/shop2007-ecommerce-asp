vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:08 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{14F6F486-E23C-4239-9A8C-E8D0C337EDA3}
vti_cacheddtm:TX|11 Nov 2003 12:16:08 -0000
vti_filesize:IR|3913
vti_backlinkinfo:VX|
