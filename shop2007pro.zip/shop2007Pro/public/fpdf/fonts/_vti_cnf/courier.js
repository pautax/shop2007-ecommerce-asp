vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:18:54 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{6ED3000B-85ED-4EED-AAFB-01E23D2AC351}
vti_cacheddtm:TX|11 Nov 2003 12:18:54 -0000
vti_filesize:IR|288
vti_backlinkinfo:VX|
