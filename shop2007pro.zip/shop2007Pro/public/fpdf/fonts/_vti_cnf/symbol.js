vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:02 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{85B71FBD-1C0F-4A21-B34A-8C6CD35C9594}
vti_cacheddtm:TX|11 Nov 2003 12:16:02 -0000
vti_filesize:IR|3948
vti_backlinkinfo:VX|
