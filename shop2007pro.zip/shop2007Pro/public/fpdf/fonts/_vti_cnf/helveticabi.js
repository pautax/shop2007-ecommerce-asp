vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:00 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{D2D4D3D0-465C-4305-8F27-2E25078DB3F0}
vti_cacheddtm:TX|11 Nov 2003 12:16:00 -0000
vti_filesize:IR|4025
vti_backlinkinfo:VX|
