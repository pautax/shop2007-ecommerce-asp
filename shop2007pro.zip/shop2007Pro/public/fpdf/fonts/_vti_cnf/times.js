vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|11 Nov 2003 12:16:04 -0000
vti_extenderversion:SR|5.0.2.2623
vti_lineageid:SR|{851DEE01-B1D0-4FF1-BB1F-6E7C3FE66ED2}
vti_cacheddtm:TX|11 Nov 2003 12:16:04 -0000
vti_filesize:IR|4016
vti_backlinkinfo:VX|
